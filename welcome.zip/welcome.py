
def hi(event, context):
    return "This function is deployed from CloudFormation"
